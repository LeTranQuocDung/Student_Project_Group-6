package trafficintersection;

import java.util.*;

public class Intersection {
    public String name;
    public TrafficLight trafficLight;
    private ArrayList<Vehicle> vehicles;
    private Random rand = new Random();
    private int vehicleCount = 0;
    
    public Intersection() {
        this("Default Intersection");
    }

    public Intersection(String name) {
        this.name = name;
        this.trafficLight = new TrafficLight();
        this.vehicles = new ArrayList<>();
    }

    public synchronized void incrementVehicleCount() {
        vehicleCount++;
    }

    public void arrive(Vehicle v) {
        vehicles.add(v);
        System.out.println(v + " arrived at intersection.");
    }

    public void randomVehicleArrival() {
        String[] directions = {"North", "South", "East", "West"};
        String dir = directions[rand.nextInt(directions.length)];
        int speed = 40 + rand.nextInt(30);
        
        vehicleCount++; 

        int type = rand.nextInt(3);
        Vehicle v;
        if (type == 0)
            v = new Car("C" + vehicleCount, dir, speed, 4 + rand.nextInt(4));
        else if (type == 1)
            v = new Truck("T" + vehicleCount, dir, speed, 1000 + rand.nextInt(4000));
        else
            v = new Bus("B" + vehicleCount, dir, speed, 10 + rand.nextInt(5));

        arrive(v);
    }
    
    public void update() {
        trafficLight.displayStatus();
        for (Vehicle v : vehicles) {
            String light = trafficLight.getLightFor(v.getDirection());
            if (light.equals("Green"))
                v.move();
            else
                v.stop();
        }
    }

    public void displayStatus() {
        trafficLight.displayStatus();
        for (Vehicle v : vehicles) {
            String light = trafficLight.getLightFor(v.getDirection());
            System.out.println(v + " -> " + (light.equals("Green") ? "Moving" : "Waiting"));
        }
        System.out.println("------------------------------------");
    }
}