package trafficintersection;

public class Truck extends Vehicle {
    private int loadWeight;

    public Truck(String id, String direction, int speed, int loadWeight) {
        super(id, "Truck", direction, speed);
        this.loadWeight = loadWeight;
    }
  
    @Override
    public void move() {
        super.move(); 
       
        System.out.println("  -> Detail: Carrying " + loadWeight + " kg of load.");
    }
    
    
    @Override
    public void stop() {
        super.stop(); 
        System.out.println("  -> Detail: Carrying " + loadWeight + " kg of load.");
    }

    public int getLoadWeight() {
        return loadWeight;
    }
}