
package trafficintersection;

/**
 *
 * @author Admin
 */
public class Vehicle {
    protected String id;
    protected String type;
    protected String direction;
    protected int speed;
    protected boolean isWaiting;

    public Vehicle(String id, String type, String direction, int speed) {
        this.id = id;
        this.type = type;
        this.direction = direction;
        this.speed = speed;
        this.isWaiting = false;
    }

    public void move() {
        isWaiting = false;
        System.out.println(type + " " + id + " from " + direction + " is moving at " + speed + " km/h.");
    }

    public void stop() {
        isWaiting = true;
        System.out.println(type + " " + id + " from " + direction + " stopped at red light.");
    }

    public String getDirection() {
        return direction;
    }

    @Override
    public String toString() {
        return type + " " + id + " (" + direction + ")";
    }
}
