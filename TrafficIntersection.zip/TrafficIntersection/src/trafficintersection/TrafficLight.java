/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trafficintersection;

/**
 *
 * @author Admin
 */
public class TrafficLight {
    private boolean isNSGreen; 
    private int timer;

    public TrafficLight() {
        this.isNSGreen = true;
        this.timer = 10;
    }

    public void changeLight() {
        isNSGreen = !isNSGreen;
        timer = 10;
        System.out.println(" Light changed!");
    }

    public void countdown() {
        timer--;
        if (timer <= 0) {
            changeLight();
        }
    }

    public String getLightFor(String direction) {
        if (isNSGreen && (direction.equals("North") || direction.equals("South")))
            return "Green";
        if (!isNSGreen && (direction.equals("East") || direction.equals("West")))
            return "Green";
        return "Red";
    }

    public void displayStatus() {
        System.out.println("[Light Status] NS: " + (isNSGreen ? "Green" : "Red")
                + " | EW: " + (isNSGreen ? "Red" : "Green")
                + " | Time left: " + timer + "s");
    }
}

