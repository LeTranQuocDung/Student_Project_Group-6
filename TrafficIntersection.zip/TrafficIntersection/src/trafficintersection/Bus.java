package trafficintersection;

public class Bus extends Vehicle {
    private int routeNumber;

    public Bus(String id, String direction, int speed, int routeNumber) {
        super(id, "Bus", direction, speed);
        this.routeNumber = routeNumber;
    }
    
    
    @Override
    public void move() {
        super.move(); 
        
        System.out.println("  -> Detail: Serving Route " + routeNumber + ".");
    }
  
    @Override
    public void stop() {
        super.stop(); 
       
        System.out.println("  -> Detail: Serving Route " + routeNumber + ".");
    }

    public int getRouteNumber() {
        return routeNumber;
    }
}