/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trafficintersection;

/**
 *
 * @author Admin
 */
public class TrafficIntersection {
    public static void main(String[] args) throws InterruptedException {
      Intersection intersection = new Intersection("Main Crossroad");


        System.out.println(" Traffic Simulation Starting...\n");

       
        for (int time = 0; time < 60; time++) {
            if (time % 5 == 0) { 
                intersection.randomVehicleArrival();
            }

            intersection.update();
            Thread.sleep(1000); 
            intersection.trafficLight.countdown();
        }

        System.out.println(" Simulation finished!");
    }
}

