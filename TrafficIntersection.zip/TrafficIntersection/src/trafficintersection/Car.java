package trafficintersection;

public class Car extends Vehicle {
    private int seatCount;

    public Car(String id, String direction, int speed, int seatCount) {
        super(id, "Car", direction, speed);
        this.seatCount = seatCount;
    }
    
  
    @Override
    public void move() {
        super.move(); 
    
        System.out.println("  -> Detail: This car has " + seatCount + " seats.");
    }
    
    @Override
    public void stop() {
        super.stop(); 
       
        System.out.println("  -> Detail: This car has " + seatCount + " seats.");
    }

    public int getSeatCount() {
        return seatCount;
    }
}
